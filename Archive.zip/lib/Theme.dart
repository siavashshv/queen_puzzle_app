import 'package:flutter/material.dart';

class AppColors extends StatelessWidget
{
    // Colors //
    static Color appTheme = Color(0xFF0858C4);
    static Color appButton = Color(0xFF0086F6);

    static Color darkBox = Color(0xFF000000);
    static Color lightBox = Color(0xFFFFFFFF);
    static Color takenBox = Color(0xFFEA0858);
    static Color closedBox = Color(0xFF000000);

    @override
    Widget build(BuildContext context)
    {
        return null;
    }
}