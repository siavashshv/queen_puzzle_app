import 'dart:math';

import 'package:eight_queens_game/validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:eight_queens_game/Theme.dart';

// ignore: must_be_immutable
class ChessTable extends StatefulWidget {
  final int chessTableLength = 8;
  int queens = 0;

  @override
  ChessTableState createState() => ChessTableState();
}

class ChessTableState extends State<ChessTable> {
  // Chess items //
  List<List<String>> chessTable = [
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
    ['', '', '', '', '', '', '', ''],
  ];
  @override
  void initState() {
    _makeRandom();
    super.initState();
  }

  Widget buildChessTable() {
    return Column(children: <Widget>[
      AspectRatio(
          aspectRatio: 1.0,
          child: Container(
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.0),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.grey.withOpacity(0.4),
                        offset: Offset(4, 6),
                        blurRadius: 6.0,
                        spreadRadius: 2.0)
                  ]),
              child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: widget.chessTableLength),
                  itemBuilder: buildTable,
                  itemCount:
                      widget.chessTableLength * widget.chessTableLength)))
    ]);
  }

  Widget buildTable(BuildContext context, int index) {
    int chessTableLength = chessTable.length;
    int row, column = 0;
    row = (index / chessTableLength).floor();
    column = (index % chessTableLength);

    return GestureDetector(
        onTap: () => putAQueen(row, column),
        child: GridTile(
            child: Container(
                decoration: BoxDecoration(
                    border:
                        Border.all(color: AppColors.closedBox, width: 0.25)),
                child: Center(
                    child: MouseRegion(
                        cursor: MaterialStateMouseCursor.clickable,
                        child: buildGridItems(row, column))))));
  }

  void putAQueen(int row, int column) {
    // we check here  if the placement is empty//
    if (chessTable[row][column] == '') {
      // we put Queen in the chessTable and add the count of queens
      Validator validator = Validator();
      if (validator.isValidatePlacement(chessTable, row, column)) {
        chessTable[row][column] = 'Q';
        widget.queens++;
        print(widget.queens);
        if (widget.queens == widget.chessTableLength) {
          showWinMessage();
        }
      } else {
        _showError(validator.reason);
      }
    } else {
      chessTable[row][column] = '';
      widget.queens--;
    }

    setState(() {});
  }

  bool isSnackbarActive = false;
  void showWinMessage() {
    // Muestra el mensaje de victoria si no hay SnackBars activas //
    if (!isSnackbarActive) {
      isSnackbarActive = true;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(
            content: Padding(
                padding: EdgeInsets.symmetric(vertical: 6.88),
                child: Text('You Won The Match',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16))),
            backgroundColor: AppColors.closedBox,
            duration: Duration(milliseconds: 2888),
          ))
          .closed
          .then((SnackBarClosedReason reason) {
        isSnackbarActive = false;
      });
    }
  }

  Widget buildGridItems(int row, int column) {
    if (chessTable[row][column] == 'Q') {
      return Container(
          color: ((row % 2 == 0 && column % 2 == 0) ||
                  (row % 2 != 0 && column % 2 != 0))
              ? AppColors.darkBox
              : AppColors.lightBox,
          width: double.infinity,
          height: double.infinity,
          child: Center(
              child: Container(
                  child: FractionallySizedBox(
                      alignment: Alignment.center,
                      widthFactor: 0.80,
                      heightFactor: 0.80,
                      child: SvgPicture.asset(
                        "img/queen.svg",
                        color: Colors.red,
                      )))));
    } else {
      // if both of row and column was even or both them
      //was odd it is black else it is white
      return Container(
          color: ((row % 2 == 0 && column % 2 == 0) ||
                  (row % 2 != 0 && column % 2 != 0))
              ? AppColors.darkBox
              : AppColors.lightBox);
    }
  }

  void reset() {
    for (int i = 0; i < widget.chessTableLength; i++) {
      for (int i2 = 0; i2 < widget.chessTableLength; i2++) {
        chessTable[i][i2] = '';
      }
    }
    widget.queens = 0;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // Instrucciones del juego al iniciar //

    return

        // Escritorio //
        Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
          // Margen izquierdo para centrar el tablero sin contar el panel de botones //
          SizedBox(width: MediaQuery.of(context).size.width * 0.05),

          // Tablero de ajedrez //
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: AspectRatio(
                aspectRatio: 1, child: Container(child: buildChessTable())),
          ),

          SizedBox(width: 14.0),
          Padding(
            padding: const EdgeInsets.all(32.0),
            child: SizedBox(
              width: MediaQuery.of(context).size.width,
              child: ElevatedButton(
                  onPressed: () {
                    reset();
                  },
                  child: Text('Reset Game')),
            ),
          ),
          // Panel vertical de botones //
        ]);
  }

  void _showError(List<String> reason) {
    String resultText = '';
    for (String s in reason) {
      resultText += s + '\n';
    }
    isSnackbarActive = true;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(
          content: Padding(
              padding: EdgeInsets.symmetric(vertical: 6.88),
              child: Text(resultText,
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 16))),
          backgroundColor: AppColors.closedBox,
          duration: Duration(milliseconds: 2888),
        ))
        .closed
        .then((SnackBarClosedReason reason) {
      isSnackbarActive = false;
    });
  }

  void _makeRandom() {
    int randomRow = Random().nextInt(7);
    int randomColumn = Random().nextInt(7);
    chessTable[randomRow][randomColumn] = 'Q';
    setState(() {});
  }
}
